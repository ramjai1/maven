/**
 * 
 */
package com.denofprogramming.random;


/**
 * @author denOfProgramming
 *
 */
public interface RandomGenerator
{

    String name();

    GeneratedRandomIdentifier generate();

}
